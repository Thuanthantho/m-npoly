#pragma once

typedef struct {
	int id;
	char* name;
	int money;
	int jailed;
	int position;
} Game_Player;